To start the app use command-line with following command:

_java -jar symbolsCorrelationApp.jar_

`Note: You need JRE 1.8 to be installed on your system.`

Options:

lastXMonth=18 -> amount of month to scan (optional)

startDate=1.1.2015 -> start date to scan

endDate=1.1.2016 -> end date to scan

Files that should be in the same directory:

- positionsTable.csv
- correlation_table_full.csv
